package com.seproj.emergencysos;

public class LocationHelper {
    private String email;
    private double Longitude;
    private double Latitude;
    private String token;

    public LocationHelper(String email, double longitude, double latitude, String token) {
        this.email = email;
        Longitude = longitude;
        Latitude = latitude;
        this.token = token;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getLongitude() {
        return Longitude;
    }

    public void setLongitude(double longitude) {
        Longitude = longitude;
    }

    public double getLatitude() {
        return Latitude;
    }

    public void setLatitude(double latitude) {
        Latitude = latitude;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
